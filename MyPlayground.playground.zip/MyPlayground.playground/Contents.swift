
//1 Урок
import UIKit

var greeting = "Hello, playground"

print("Я сегодня изучил:")
print("Основы языка Swift")
print("Как использовать Playgrounds")
print("Imagine Dragons")
print("Beliver")

//2 Урок
// Task 1

let friends = 500
print(friends)

var deleteFriends = 100
print(deleteFriends)

print("Начальное количество друзей: \(friends)")

print("Обновленное количество друзей: \(deleteFriends)")


// Task 2
let goalSteps = 10000
print("Цель по шагам на день: \(goalSteps)")

//Task3
var schooling = 12
print("Количество лет обучения: \(schooling)")

schooling+=1

print("Количество обучения после дополнительного: \(schooling)")


//Task4
var steps = 0
print("Количество шагов равно в начале дня: \(steps)")

var stepsAnother = 2000
print("Количество шагов в конце дня: \(stepsAnother)")
print("Хорошая работа! Вы уже на пути к своей ежедневной цели")


//Task 5
//var name: String
//print(name)

var name: String = "Arman"
print(name)


//Task6
//var  distanceTraveled = 0
//distanceTraveled = 54.3

var distanceTraveled: Double = 0
distanceTraveled = 54.3

print("Пройденная дистанция: \(distanceTraveled)")


//3 урок

//Task 1

let width = 10
let height = 20
let area = width*height
print("Площадь сарая: \(area)")

let roomArea = area/2
print("Площадь одной комнаты: \(roomArea)")

let perimeter = width + width + height + height
print("Периметр сарая: \(perimeter)")


//Task 2

let dividend = 12
let divisor = 5
let remainder = dividend % divisor
print("Остаток от деления \(dividend) на \(divisor) равен \(remainder)")

//Task 3

let heartRate1 = 60
let heartRate2 = 80
let heartRate3 = 100

let addedHR = heartRate1 + heartRate2 + heartRate3
let averageHR = addedHR / 3

print("Сумма частоты сердечных сокращений (Int): \(addedHR)")
print("Среднее значение частоты сердечных сокращений (Int): \(averageHR)")

let heartRate1D: Double = 60.0
let heartRate2D: Double = 80.0
let heartRate3D: Double = 100.0

let addedHRD = heartRate1D + heartRate2D + heartRate3D
let averageHRD = addedHRD / 3.0

print("Сумма частоты сердечных сокращений (Double): \(addedHRD)")
print("Среднее значение частоты сердечных сокращений (Double): \(averageHRD)")

//Task 4

let steps1: Double = 3467
let goal: Double = 10000
let percentOfGoal = (steps1 / goal) * 100

print("Процент от цели, достигнутый на данный момент: \(percentOfGoal)%")

//Task 5

var balance = 0

balance += 10000
print("Баланс после работы по стрижке газона: \(balance) тенге")

balance += 20000
print("Баланс после случайных работ: \(balance) тенге")

balance /= 2
print("Баланс после траты на ужин и кино: \(balance) тенге")

balance *= 3
print("Баланс после мытья окон: \(balance) тенге")

balance -= 3000
print("Баланс после траты в магазине: \(balance) тенге")

//Task 6

print(10 + 2 * 5)
print((10 + 2) * 5)
print(4 * 9 - 6 / 2)
print(4 * (9 - 6) / 2)


// 4 урок
// Task 1

9 == 9
print(true)
print(9 == 9)

9 != 9
print(false)
print(9 != 9)

47 > 90
print(false)
print(47 > 90)

47 < 90
print(true)
print(47 < 90)

4 <= 4
print(true)
print(4 <= 4)

4 >= 5
print(false)
print(4 >= 5)

(47 > 90) && (47 < 90)
print(false)
print((47 > 90) && (47 < 90))

(47 > 90) || (47 < 90)
print(true)
print((47 > 90) || (47 < 90))

!true
print(false)
print(!true)

//Task 2

var tenge = 0
if tenge == 0 {
    print("Извини, но ты на мели!")
}

tenge = 300
if tenge == 0 {
    print("Извини, но ты на мели!")
} else {
    print("Вау, у тебя есть деньги на пирожки!")
}

tenge = 2000
if tenge == 0 {
    print("Извини, но ты на мели!")
} else if tenge < 400 {
    print("Вау, у тебя есть деньги на пирожки!")
} else {
    print("Едем на Такси!")
}


//Task 3

let hasFish = true
let hasPizza = false
let hasVegan = true

if (hasFish || hasPizza) && hasVegan {
    print("Поехали!")
} else {
    print("Извините, нам нужно выбрать другое место")
}

//Task 4

let rain = false
let temperature = 30
let sun = true

let isNiceWeather = !rain || (temperature > 27 && sun)

if isNiceWeather {
    print("Я иду на прогулку!")
}

//Task 5

let seasonNumber = 4

switch seasonNumber {
case 1:
    print("Зима")
case 2:
    print("Весна")
case 3:
    print("Лето")
case 4:
    print("Осень")
default:
    print("Такого сезона нету!")
}


//Task 6

let friendsList = ["Zhansaya", "Akezhan", "Dina", "Valerya"]

let friendsChek = "Dina"

if friendsList.contains(friendsChek) {
    print("Добро пожаловать")
} else {
    print("Вас нет в списке")
}


//Task 7

let age = 26

switch age {
case 0...2:
    print("Младенец")
case 3...14:
    print("Детский билет")
case _ where age > 14:
    print("Взрослый билет")
default:
    print("Некорректно")
}


//Task 8

let food1 = 4500
let food2 = 9000

let moreExpensiveDish = food1 > food2 ? "Блюдо 1" : "Блюдо 2"

print("Самое дорогое блюдо: \(moreExpensiveDish)")

//Task 9

let schedule: [Int: String] = [
    1: "Прием у врача",
    2: "Встреча с друзьями",
    3: "Сходить в кинотеатр",
    4: "Защита проекта",
    5: "Сходить в салон",
    6: "Тренировка по бегу",
    7: "Время с семьей"
]

let day = 2

if let event = schedule[day] {
    print(event)
} else {
    print("Некорректный номер дня недели. Пожалуйста, введите число от 1 до 7.")
}

//Task 10
let stations = [
    "A": ("Станция А", "15 минут"),
    "B": ("Станция B", "20 минут"),
    "C": ("Станция C", "25 минут"),
    "D": ("Станция D", "30 минут"),
    "E": ("Станция E", "10 минут")
]
var userInput = "b"
let normalizedInput = userInput.uppercased()
if let (name, travelTime) = stations[normalizedInput] {
    print("Станция: \(name), Время в пути: \(travelTime)")
} else {
    print("Станция с кодом \(userInput) не найдена. Пожалуйста, введите корректную букву (A, B, C, D, E).")
}

//Task 11

let fingers: [Int: String] = [
    1: "Первый",
    2: "Второй",
    3: "Третий",
    4: "Четвертый",
    5: "Пятый"
]

var user = 3

if let fingerName = fingers[user] {
    print("Палец номер \(user): \(fingerName)")
} else {
    print("Палец с номером \(user) не существует. Пожалуйста, введите число от 1 до 5.")
}

//Урок 5
//Task 1

var myName = "Айжан"
print("Меня зовут: \(myName)")

let favoriteQuote = "Что ни делается, все к лучшему​"
print("Моя любимая цитата - \"\(favoriteQuote)\"")

let emptyString = ""
if emptyString.isEmpty {
    print("Здесь ничего нет")
} else {
    print("Она не пуста, как я думал")
}

//Task 2

let city = "Алматы"
let region = "Алматинская область"
let home = city + ", " + region
print("Дом: \(home)")

var introduction = "Я живу в "
introduction += home
print(introduction)

let name2 = "Айжан"
let myAge = 26
print("Меня зовут \(name2), и на следующий год мне будет \(myAge + 1) лет.")


//Task 3

let nameMy = "Айжан"
let surname = "Замкенова"
let fullName = "\(nameMy) \(surname)"

let record = 10000
let newRecord = 15000
let congratulations = "Поздравляем, \(fullName)! Вы превзошли свой предыдущий рекорд в \(record) шагов, сделав \(newRecord) шагов вчера!"
print(congratulations)

//Task 4

//1
let nameInCaps: String = "АЙЖАН"
let nameLittle: String = "айжан"

if nameInCaps.uppercased() == nameLittle.uppercased() {
    print("Эти две строки равны")
} else {
    print("Эти две строки не равны")
}

if nameInCaps.lowercased() == name.lowercased() {
    print("\(nameInCaps) и \(name) совпадают")
} else {
    print("\(nameInCaps) и \(name) не совпадают")
}

//2

let hisName = "Robert Downey Jr."
if hisName.hasSuffix("Jr.") {
    print("Это имя используется второе поколение")
} else {
    print("Это имя не используется второе поколение")
}

//3

let textToSearchThrough = "быть или не быть вот в чем вопрос"
let textToSearchFor = "быть или не быть"

if textToSearchThrough.lowercased().contains(textToSearchFor.lowercased()) {
    print("Я нашел!")
} else {
    print("Фраза не найдена.")
}

//4

let myNameIs = "Айжан"
let numberOfCharacters = myNameIs.count
print("Количество символов в имени \(myNameIs): \(numberOfCharacters)")
